package com.mark.level;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.graphics.drawable.shapes.RectShape;
import android.util.AttributeSet;
import android.util.Log;

import com.mark.nevex.Board;
import com.mark.nevex.Edge;

public class ShapeFactory {

	BoxToken[][] boxBoundaries;
	MyShapeDrawable[][][] boardShapes;
	public ArrayList<MyShapeDrawable> currentShapes = new ArrayList<MyShapeDrawable>();
	public ArrayList<ShapeDrawable> fillerShapes = new ArrayList<ShapeDrawable>();
	private Board board;
	
	private int debugCirclesDrawn, debugLinesDrawn;
	
	public ShapeFactory(Board b)
	{
		this.board = b;
		debugCirclesDrawn = debugLinesDrawn = 0;
	}
	
	public void DrawBoard()
	{
		this.drawRowsAndColumns();
		this.drawGameBorder();
	}

	private void drawRowsAndColumns() {
		int prevX, prevY;
		prevX = prevY = determineStartCoOrds();

		int currentRow = 0;
		int currentCol = 0;
		
		boardShapes = new MyShapeDrawable[BoardSettings.boardColumns][BoardSettings.boardRows][4];
		boxBoundaries = new BoxToken[BoardSettings.boardColumns][BoardSettings.boardRows];

		for ( int rows = 0; rows < BoardSettings.boardRows; rows++)
		{
			createOneRowOfHorizontalShapes(prevX, prevY, currentRow, currentCol,rows);

			prevY = createOneRowOfVerticalShapes(prevX, prevY, currentRow, currentCol);
			prevX = determineStartCoOrds();
			
			currentCol = 0;
			// Check if we are in the last row
			if ( rows == BoardSettings.boardRows - 1)
			{
				createOneRowOfHorizontalShapes(prevX, prevY, currentRow, currentCol, rows);
			}
			currentRow++;
		}
		
	}

	private int createOneRowOfVerticalShapes(int x, int y, int currentRow, int currentCol) {

		for (int c = 0; c <= BoardSettings.boardColumns; c++)
		{
			x = this.shapeCreatorForColumns(BoardSettings.boardColumns, x, y, currentRow, currentCol, c);
			currentCol++;
		}
		return y + BoardSettings.lineWidth + BoardSettings.lineGap;
	}

	private void createOneRowOfHorizontalShapes(int x, int y, int currentRow, int currentCol, int rows) {
		for (int i = 0; i < BoardSettings.boardColumns; i++)
		{ 
			x = this.shapeCreatorForRows(x, y, currentRow, currentCol, rows, i, false);
			currentCol++;
		}
		Log.d("measure", "width of board from drawing: "+x+", width from calc "+BoardSettings.myCanvasWidth);
	}

	private int determineStartCoOrds() {
		return BoardSettings.boardBorderWidth + BoardSettings.borderGapToBoard;
	}


	private int shapeCreatorForColumns(int boardColumns, int x, int y, int currentRow, int currentCol, int c) {
		MyShapeDrawable newDrawableLine;
		Rect newRect = new Rect(
						x, 
						y + BoardSettings.lineGap, 
						x + BoardSettings.lineHeight, 
						y + BoardSettings.lineWidth + BoardSettings.lineGap
						);
		if ( c == boardColumns ) 
		{
			// last column is also the previous column
			newDrawableLine = this.createRectShape(newRect, currentCol - 1, currentRow, Edge.EAST);
			boardShapes[currentCol - 1][currentRow][Edge.EAST] = newDrawableLine;
		}
		else 
		{
			newDrawableLine = this.createRectShape(newRect, currentCol, currentRow, Edge.WEST);
			boardShapes[currentCol][currentRow][Edge.WEST] = newDrawableLine;
			if ( currentCol > 0 ) {
				boardShapes[currentCol - 1][currentRow][Edge.EAST] = newDrawableLine;
			}
		}
		return newDrawableLine.getBounds().right + BoardSettings.lineWidth;
		
	}

	private int shapeCreatorForRows(int x, int y, int currentRow, int currentCol, int rows, int i, boolean isLastRow) {
		if ( currentCol == 0 )
		{
			// in first column, so draw the first circle
			this.createAndAddNewLayoutBoardCircle(x, y);
		}

		int rightSideOfLine = x + BoardSettings.lineWidth + BoardSettings.lineGap;
		Rect newRect = new Rect(
					x + BoardSettings.lineGap, 
					y, 
					rightSideOfLine, 
					y + BoardSettings.lineHeight
					);
		MyShapeDrawable newDrawableLine = this.createRectShape(newRect, currentCol, currentRow, Edge.NORTH);
		if (isLastRow)
		{
			boardShapes[currentCol][currentRow][Edge.SOUTH] = newDrawableLine;
		}
		else
		{
			boardShapes[currentCol][currentRow][Edge.NORTH] = newDrawableLine;
			if ( currentRow > 0 ) {
				boardShapes[currentCol][currentRow - 1][Edge.SOUTH] = newDrawableLine;
			}
		}
		// draw the circle after the line
		this.createAndAddNewLayoutBoardCircle(rightSideOfLine, y);
		addGameBoxDefinitions(rows, i, newDrawableLine);
		return rightSideOfLine;
	}

	private void addGameBoxDefinitions(int rows, int i, MyShapeDrawable newDrawableLine) {
		Rect boxBounds = new Rect();
		boxBounds.top = newDrawableLine.getBounds().bottom;
		boxBounds.left = newDrawableLine.getBounds().left;
		boxBounds.right = newDrawableLine.getBounds().right;
		boxBounds.bottom = boxBounds.top + BoardSettings.lineWidth;
		BoxToken bt = new BoxToken();
		bt.tokenRect = boxBounds;
		this.boxBoundaries[i][rows] = bt;
		Log.d("box", "["+i+"]["+rows+"] -- "+boxBounds.left+","+boxBounds.top+","+boxBounds.right+","+boxBounds.bottom);
	}
	
	private void createAndAddNewLayoutBoardCircle(int prevX, int prevY) {
		ShapeDrawable circle = new ShapeDrawable(new OvalShape());
		circle.setBounds(prevX + BoardSettings.getCircleStartBounds(), 
				prevY + BoardSettings.getCircleStartBounds(), 
				prevX + BoardSettings.getCircleEndBounds(), 
				prevY + BoardSettings.getCircleEndBounds() );
		circle.getPaint().setColor(Color.WHITE);
		fillerShapes.add(circle);
		debugCirclesDrawn++;
	}
	
	private void drawGameBorder() {
		ShapeDrawable borderTop = new ShapeDrawable(new RectShape());
		borderTop.setBounds(0, 0, (int)BoardSettings.myCanvasWidth, BoardSettings.boardBorderWidth);

		ShapeDrawable borderBottom = new ShapeDrawable(new RectShape());
		borderBottom.setBounds(0, (int)BoardSettings.myCanvasHeight - BoardSettings.boardBorderWidth, (int)BoardSettings.myCanvasWidth, (int)BoardSettings.myCanvasHeight);

		ShapeDrawable borderLeft = new ShapeDrawable(new RectShape());
		borderLeft.setBounds(0, 0, BoardSettings.boardBorderWidth, (int)BoardSettings.myCanvasHeight - BoardSettings.boardBorderWidth);

		ShapeDrawable borderRight = new ShapeDrawable(new RectShape());
		borderRight.setBounds((int)BoardSettings.myCanvasWidth - BoardSettings.boardBorderWidth, 0, (int)BoardSettings.myCanvasWidth , (int)BoardSettings.myCanvasHeight);

		borderTop.getPaint().setColor(Color.WHITE);
		borderBottom.getPaint().setColor(Color.WHITE);
		borderLeft.getPaint().setColor(Color.WHITE);
		borderRight.getPaint().setColor(Color.WHITE);
		
		fillerShapes.add(borderLeft);
		fillerShapes.add(borderTop);
		fillerShapes.add(borderRight);
		fillerShapes.add(borderBottom);
	}
	
	private MyShapeDrawable createRectShape(Rect bounds, int col, int row, int edge)
	{
		MyShapeDrawable drawableLine;
		drawableLine = new MyShapeDrawable(new RectShape());
		drawableLine.getPaint().setColor(Color.TRANSPARENT);
		drawableLine.setEdge(row, col, edge, board);
		drawableLine.setBounds(bounds);
		Log.d("nevex", "adding new shape for : row "+drawableLine.myEdge.getRow()+", col "+drawableLine.myEdge.getCol()+" , edge "+drawableLine.myEdge.getEdge());
		currentShapes.add(drawableLine);
		debugLinesDrawn++;
		return drawableLine;
	}

	
}
