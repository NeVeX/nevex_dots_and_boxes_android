package com.mark.level;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.graphics.drawable.shapes.RectShape;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Display;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.view.WindowManager;
import android.widget.TextView;

import com.mark.GameManager;
import com.mark.R;
import com.mark.nevex.AIEngine;
import com.mark.nevex.Board;
import com.mark.nevex.Edge;
import com.mark.nevex.Edges;
import com.mark.nevex.NeVeX;
import com.mark.nevex.Viper;

public class DrawLevel extends View {
	private int lineWidth = 100;
	private int lineHeight = 20;
	private int boardStartX;
	private int boardStartY;
	private int gameBorderWidth = 20;
	private int lineGap = 20;
	private int circleStartBounds;
	private int circleEndBounds;
	private boolean nevexComputing;
	private boolean gameJustStated;
	private ArrayList<ShapeDrawable> fillerShapes = new ArrayList<ShapeDrawable>();
	private int boardPadding = 50;
	private int boardRows, boardColumns;
	private ArrayList<MyShapeDrawable> currentShapes = new ArrayList<MyShapeDrawable>();
	private MyShapeDrawable[][][] boardShapes;
	private Board b;
	private BoxToken[][] boxBoundaries;
	private AIEngine aiEngine;
	private MyShapeDrawable prevSelecetedShape;
	float myCanvasWidth, myCanvasHeight;
	private long touchDownTime;
	//These two constants specify the minimum and maximum zoom
	private static float MIN_ZOOM = -3f;
	private static float MAX_ZOOM = 5f;
	private float scaleFactor = 1.f;
	private ScaleGestureDetector detector;
	//These constants specify the mode that we're in
	private static int NONE = 0;
	private static int DRAG = 1;
	private static int ZOOM = 2;
	private int mode;
	//These two variables keep track of the X and Y coordinate of the finger when it first
	//touches the screen
	private float startX = 0f;
	private float startY = 0f;
	//These two variables keep track of the amount we need to translate the canvas along the X
	//and the Y coordinate
	private float translateX = 0f;
	private float translateY = 0f;
	//These two variables keep track of the amount we translated the X and Y coordinates, the last time we
	//panned.
	private float previousTranslateX = 0f;
	private float previousTranslateY = 0f;    
	private boolean dragged = false;
	private float displayWidth;
	private float displayHeight;

	@Override
	public boolean onTouchEvent(MotionEvent event) {

		Log.d("Touching", "");
		Log.d("Touching", "New touch event registered");
		switch (event.getAction() & MotionEvent.ACTION_MASK) {

		case MotionEvent.ACTION_DOWN:

			Log.d("Touching", "Action Down. Previous Mode is :"+mode+", new mode is :"+DRAG);
			touchDownTime = SystemClock.elapsedRealtime();

			mode = DRAG;

			//We assign the current X and Y coordinate of the finger to startX and startY minus the previously translated
			//amount for each coordinates This works even when we are translating the first time because the initial
			//values for these two variables is zero.
			startX = event.getX() - previousTranslateX;
			startY = event.getY() - previousTranslateY;

			break;

		case MotionEvent.ACTION_MOVE:
			translateX = event.getX() - startX;
			translateY = event.getY() - startY;

			Log.d("Touching", "Action Move. Previous Mode is :"+mode+", new mode is :"+DRAG);
			Log.d("Touching", "new translate ["+translateX+", "+translateY+"] - Event ["+event.getX()+", "+event.getY()+"] - StartPositions["+startX+", "+startY+"]");
			//We cannot use startX and startY directly because we have adjusted their values using the previous translation values.
			//This is why we need to add those values to startX and startY so that we can get the actual coordinates of the finger.
			double distance = Math.sqrt(Math.pow(event.getX() - (startX + previousTranslateX), 2) +
					Math.pow(event.getY() - (startY + previousTranslateY), 2)
					);

			if(distance > 0) {
				dragged = true;
				Log.d("Touching", "Action Move. Is being dragged");
			}               

			break;

		case MotionEvent.ACTION_POINTER_DOWN:

			Log.d("Touching", "Action Pointer Down. Previous Mode is :"+mode+", new mode is :"+ZOOM);
			mode = ZOOM;
			break;

		case MotionEvent.ACTION_UP:
			Log.d("Touching", "Action Up. Previous Mode is :"+mode+", new mode is :"+NONE);
			mode = NONE;

			if (SystemClock.elapsedRealtime() - touchDownTime <= 100 )
			{
				Log.d("Touching", "Action Pointer Down - Player wants to make a move");
				this.makePlayerMoveInUI(event);
			}

			dragged = false;

			//All fingers went up, so let's save the value of translateX and translateY into previousTranslateX and
			//previousTranslate
			previousTranslateX = translateX;
			previousTranslateY = translateY;
			break;

		case MotionEvent.ACTION_POINTER_UP:

			Log.d("Touching", "Action Pointer Up. Previous Mode is :"+mode+", new mode is :"+DRAG);
			mode = DRAG;

			//This is not strictly necessary; we save the value of translateX and translateY into previousTranslateX
			//and previousTranslateY when the second finger goes up
			previousTranslateX = translateX;
			previousTranslateY = translateY;
			break;

		}




		//        detector.onTouchEvent(event);

		//We redraw the canvas only in the following cases:
		//
		// o The mode is ZOOM
		//        OR
		// o The mode is DRAG and the scale factor is not equal to 1 (meaning we have zoomed) and dragged is
		//   set to true (meaning the finger has actually moved)
		if ((mode == DRAG /* && scaleFactor != 1f */ && dragged) || mode == ZOOM) {
			//            invalidate();
		}
		invalidate();
		return true;
	}

	@Override
	public void onDraw(Canvas canvas) {
		Log.d("Draw", "In onDraw - Translate ["+translateX+", "+translateY+"]");
		super.onDraw(canvas);

		canvas.save();

		//We're going to scale the X and Y coordinates by the same amount
		//        canvas.scale(scaleFactor, scaleFactor);

		//        If translateX times -1 is lesser than zero, let's set it to zero. This takes care of the left bound
		if( (translateX * - 1) < 0) {
			Log.d("Touching", "translateX set to 0");
			translateX = 0;
		}
		//This is where we take care of the right bound. We compare translateX times -1 to (scaleFactor - 1) * displayWidth.
		//If translateX is greater than that value, then we know that we've gone over the bound. So we set the value of
		//translateX to (1 - scaleFactor) times the display width. Notice that the terms are interchanged; it's the same
		//as doing -1 * (scaleFactor - 1) * displayWidth
		//        else if( (translateX * -1) > (scaleFactor - 1) * displayWidth) {
		//           translateX = (1 - scaleFactor) * displayWidth;
		//        }
		else if( (translateX * -1) > ( myCanvasWidth - displayWidth)) {
			translateX = (myCanvasWidth - displayWidth) * -1;
			Log.d("Touching", "translateX set to "+translateX);
		}
		//
		if( (translateY * - 1) < 0) {
			Log.d("Touching", "translateY set to 0");
			translateY = 0;
		}
		//        //We do the exact same thing for the bottom bound, except in this case we use the height of the display
		//        else if( (translateY * -1) > (scaleFactor - 1) * displayHeight) {
		//           translateY = (1 - scaleFactor) * displayHeight;
		//        }
		else if( (translateY * -1) > ( myCanvasHeight - displayHeight) ) {

			translateY = (myCanvasHeight - displayHeight) * -1;
			Log.d("Touching", "translateY set to "+translateY);
		}

		//We need to divide by the scale factor here, otherwise we end up with excessive panning based on our zoom level
		//because the translation amount also gets scaled according to how much we've zoomed into the canvas.
		Log.d("draw", "Translating: "+translateX+", "+translateY+", "+scaleFactor);

		//        canvas.translate((translateX / scaleFactor) + moveX, (translateY / scaleFactor) + moveY);
		canvas.translate(translateX, translateY);
		//        canvas.translate(100f, 100f);


		for (MyShapeDrawable d : currentShapes)
		{
			if (d.isVisible())
			{
				d.draw(canvas);
			}
		}

		for ( ShapeDrawable c: fillerShapes )
		{
			c.draw(canvas);
		}

		Log.d("nevex", "Human Score: "+Scores.HumanScore);
		Log.d("nevex", "NeVeX Score: "+Scores.AIScore);
		setUpTextViews();
		if (gameJustStated )
		{
			updateStatusGameText("Human, Make Your Move.");
			gameJustStated = false;
		} 


		/* The rest of your canvas-drawing code */
		canvas.restore();



	}

	private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
		@Override
		public boolean onScale(ScaleGestureDetector detector) {
			scaleFactor *= detector.getScaleFactor();
			scaleFactor = Math.max(MIN_ZOOM, Math.min(scaleFactor, MAX_ZOOM));
			return true;
		}
	}

	protected void onFinishInflate()
	{
		this.resetBoard();	
	}

	protected void onMeasure(int width, int height)
	{
		setMeasuredDimension((int)this.displayWidth+1, (int)this.displayHeight+1); 	    
	}

	private MyShapeDrawable createRectShape(int x, int y, boolean vertical, int row, int col, int edge)
	{
		Log.d("nevex", "creating shape with the following dimensions: "+x+", "+y+", "+vertical+", "+row+", "+col+", "+edge);
		MyShapeDrawable drawableLine;
		int width = lineWidth;
		int height = lineHeight;

		drawableLine = new MyShapeDrawable(new RectShape());
		drawableLine.getPaint().setColor(Color.TRANSPARENT);
		if ( vertical )
		{
			//	    	 drawableLine.edge = Edge.WEST;
			drawableLine.setEdge(col, row, edge, b);
			drawableLine.setBounds(x, y+lineGap, x + height, y + width);
		}
		else
		{
			//	    	 drawableLine.edge = Edge.NORTH;
			drawableLine.setEdge(col, row, edge, b);
			drawableLine.setBounds(x+lineGap, y, x + width, y + height);

			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			// START HERE - COMMENT OUT THIS AND SEE WHAT HAPPENS - COUNT THE EDGES AND CIRCLES BEING ADDED
			this.createAndAddNewLayoutBoardCircle(x+lineGap+width, y);
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
//			ShapeDrawable circle = new ShapeDrawable(new OvalShape());
//
//			circle.setBounds(x + width + circleStartBounds, y, x + width + circleEndBounds, y + height );
//			circle.getPaint().setColor(Color.WHITE);
//			fillerShapes.add(circle);
//			
//			
//			ShapeDrawable circle = new ShapeDrawable(new OvalShape());
//			circle.setBounds(prevX, prevY, prevX  + circleEndBounds, prevY + lineHeight );
//			circle.getPaint().setColor(Color.WHITE);
//			fillerShapes.add(circle);
			

		}

		Log.d("nevex", "adding new shape for : row "+drawableLine.myEdge.getRow()+", col "+drawableLine.myEdge.getCol()+" , edge "+drawableLine.myEdge.getEdge());
		currentShapes.add(drawableLine);

		return drawableLine;
	}

	public DrawLevel(Context context, AttributeSet as)
	{
		super(context, as);
		setPadding(boardPadding, boardPadding, boardPadding, boardPadding);
		detector = new ScaleGestureDetector(getContext(), new ScaleListener());

		WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
		Display display = wm.getDefaultDisplay();
		displayWidth = display.getWidth();
		displayHeight = display.getHeight();

		//    	 this.setLayoutParams(new LayoutParams(300, 300));
		gameJustStated = true;
		boardRows = GameManager.Rows;
		boardColumns = GameManager.Columns;
		boardShapes = new MyShapeDrawable[boardColumns][boardRows][4];
		boxBoundaries = new BoxToken[boardColumns][boardRows];
		b = new Board(this, boardColumns, boardRows);
		
		circleStartBounds = (int) ((int) lineGap * 0.3);
		circleEndBounds = (int) ((int) lineGap * 0.7);
		
		
		myCanvasWidth = (boardColumns * lineWidth) 
				+ ( (boardColumns + 3) * lineGap)
				+ (gameBorderWidth * 2) 
				/* + ( boardPadding * 2) */;
		myCanvasHeight = (boardRows * lineWidth) 
				+ ( (boardRows + 3) * lineGap) 
				+ (gameBorderWidth * 2) 
				/*  + ( boardPadding * 2) */;

		//    	 
		//    	 
		//    	 7 x 100 = 700
		//    			 + 7 * 20
		//    			 = 700 + 140
		//    			 = 840

		this.drawGameBorder();

		Log.d("nevex", "new board is: \n"+b.toString());


		if ( GameManager.aiEngine.equals("NeVeX"))
		{

			aiEngine = new NeVeX(b);
		}
		else
		{
			aiEngine = new Viper(b);
		}


		//    	 int gap = 0;
		
		
		boardStartX = gameBorderWidth + lineGap;
		boardStartY = boardStartX;
		
		int prevX = boardStartX;
		int prevY = boardStartY;

		int currentRow = 0;
		int currentCol = 0;

		for ( int rows = 0; rows < boardRows; rows++)
		{
			for (int i = 0; i < boardColumns; i++)
			{ 
				Rect boxBounds = new Rect();

				createAndAddNewLayoutBoardCircle(prevX, prevY);


				MyShapeDrawable newDrawableLine = this.createRectShape(prevX, prevY, false, currentCol, currentRow, Edge.NORTH);
				boardShapes[currentCol][currentRow][Edge.NORTH] = newDrawableLine;

				boxBounds.top = newDrawableLine.getBounds().bottom;
				boxBounds.left = newDrawableLine.getBounds().left;
				boxBounds.right = newDrawableLine.getBounds().right;
				boxBounds.bottom = boxBounds.top + ( lineWidth - lineHeight);
				BoxToken bt = new BoxToken();
				bt.tokenRect = boxBounds;
				this.boxBoundaries[i][rows] = bt;
				Log.d("box", "["+i+"]["+rows+"] -- "+boxBounds.left+","+boxBounds.top+","+boxBounds.right+","+boxBounds.bottom);

				if ( currentRow > 0 ) {
					boardShapes[currentCol][currentRow - 1][Edge.SOUTH] = newDrawableLine;
				}

				prevX = prevX + lineWidth;
				currentCol++;


			}

			prevX = boardStartX;
			currentCol = 0;
			for (int c = 0; c <= boardColumns; c++)
			{

				if ( c == boardColumns ) 
				{
					// last column is also the previous column
					MyShapeDrawable newDrawableLine = this.createRectShape(prevX, prevY, true, currentCol - 1, currentRow, Edge.EAST);
					boardShapes[currentCol - 1][currentRow][Edge.EAST] = newDrawableLine;
				}
				else 
				{
					MyShapeDrawable newDrawableLine = this.createRectShape(prevX, prevY, true, currentCol, currentRow, Edge.WEST);
					boardShapes[currentCol][currentRow][Edge.WEST] = newDrawableLine;
					if ( currentCol > 0 ) {
						boardShapes[currentCol - 1][currentRow][Edge.EAST] = newDrawableLine;
					}
				}

				prevX = prevX + lineWidth;
				currentCol++;

			}

			prevX = boardStartX;
			prevY = boardStartY + ((lineWidth) * ( rows + 1));


			// draw last line row
			if ( rows == boardRows - 1)
			{

				createAndAddNewLayoutBoardCircle(prevX, prevY);

				currentCol = 0;
				//	    		 currentRow++;
				// last row is also the previous row
				for (int i = 0; i < boardColumns; i++)
				{
					MyShapeDrawable newDrawableLine = this.createRectShape(prevX, prevY, false, currentCol, currentRow, Edge.SOUTH);
					boardShapes[currentCol][currentRow][Edge.SOUTH] = newDrawableLine;
					prevX = prevX + lineWidth;
					currentCol++;
				}
			}
			currentRow++;
			currentCol = 0;

		}


		//    	 setOnTouchListener(this);

	}

	private void createAndAddNewLayoutBoardCircle(int prevX, int prevY) {
		ShapeDrawable circle = new ShapeDrawable(new OvalShape());
		circle.setBounds(prevX, prevY, prevX  + circleEndBounds, prevY + lineHeight );
		circle.getPaint().setColor(Color.WHITE);
		fillerShapes.add(circle);
	}

	private void drawGameBorder() {

		ShapeDrawable borderTop = new ShapeDrawable(new RectShape());
		borderTop.setBounds(0, 0, (int)myCanvasWidth, gameBorderWidth);

		ShapeDrawable borderBottom = new ShapeDrawable(new RectShape());
		borderBottom.setBounds(0, (int)myCanvasHeight - gameBorderWidth, (int)myCanvasWidth, (int)myCanvasHeight);

		ShapeDrawable borderLeft = new ShapeDrawable(new RectShape());
		borderLeft.setBounds(0, 0, gameBorderWidth, (int)myCanvasHeight - gameBorderWidth);

		ShapeDrawable borderRight = new ShapeDrawable(new RectShape());
		borderRight.setBounds((int)myCanvasWidth - gameBorderWidth, 0, (int)myCanvasWidth , (int)myCanvasHeight);

		borderTop.getPaint().setColor(Color.WHITE);
		borderBottom.getPaint().setColor(Color.WHITE);
		borderLeft.getPaint().setColor(Color.WHITE);
		borderRight.getPaint().setColor(Color.WHITE);


		fillerShapes.add(borderLeft);
		fillerShapes.add(borderTop);
		fillerShapes.add(borderRight);
		fillerShapes.add(borderBottom);

	}

	private void resetBoard() {
		Scores.HumanScore = Scores.AIScore = 0;
	}

	public void setUpTextViews() {
		View v = (View) this.getRootView();

		TextView tv = (TextView) v.findViewById(R.id.scoresHumanoidText);
		TextView tv2 = (TextView) v.findViewById(R.id.scoresNeVeXText);

		tv.setText("Human Score: "+Scores.HumanScore);
		tv2.setText(aiEngine.getAIName()+" Score: "+Scores.AIScore);
	}

	private void updateStatusGameText(String text)
	{
		View v = this.getRootView();
		TextView tv = (TextView) v.findViewById(R.id.statusGameText);
		tv.setText(text);

	}

	public boolean makePlayerMoveInUI(MotionEvent event) {

		int x = (int) event.getX();
		int y = (int) event.getY();

		Log.d("Touching", "Event Co-ords: "+x+", "+y);


		if ( !this.nevexComputing && b.getEdgesLeft() > 0 )
			for (MyShapeDrawable d : currentShapes)
			{

				if ( d.getBounds().contains(x, y) && !d.alreadySelected)
				{
					Log.d("Touching", "Found shape for Event Co-ords: "+x+", "+y);
					//				Log.d("Shape Clicked", "drawable line touched with cor-ords: ["+x+", "+y+"]");
					Log.d("nevex", "Shape with edge selected: "+d.myEdge.getCol()+", "+d.myEdge.getRow()+" ,"+d.myEdge.getEdge());
					if (d.getPaint().getColor() == Color.TRANSPARENT)
					{
						d.getPaint().setColor(Color.RED);
						d.alreadySelected = true;
						setPrevShapeToNormalColor(null);
						invalidate();
					}

					if (b.acceptMove(d, d.myEdge, 0) )
					{
						// player move valid, calling on the AI engine now
						updateStatusGameText(aiEngine.getAIName()+" Is Computing....");
						this.nevexComputing = true;
						Log.d("nevex", "player move over");
						Log.d("nevex", "nevex is thinking.....");
						Edge e = aiEngine.pickEdge();
						d = findEdgeSelectedInShapes(e);
						Log.d("nevex", "nevex has made it's move: "+e.getCol()+", "+e.getRow()+" ,"+e.getEdge());

						while ( !b.acceptMove(d, e, 1) && b.getEdgesLeft() > 0)
						{
							Log.d("nevex", "nevex is thinking again.....");
							Log.d("nevex", "board accepted ths move by nevex. Finding shape to select on this move.");
							invalidate();
							e = aiEngine.pickEdge();
							d = findEdgeSelectedInShapes(e);
							Log.d("nevex", "nevex has made it's move: "+e.getRow()+", "+e.getCol()+" ,"+e.getEdge());

						}
						Log.d("nevex", "board accepted ths move by nevex. Finding last shape to select on this move.");
						findEdgeSelectedInShapes(e);
						invalidate();
						Log.d("nevex", "nevex move over");
						this.nevexComputing = false;
						updateStatusGameText(aiEngine.getAIName()+" Made Move. Human, Make Your Move.");
					}
					else
					{
						// human player got a box
						//					placeTokenInsideWinnerBox(d);
						updateStatusGameText("Human, Again, Make Your Move.");
						Log.d("nevex", "player gets to go again");
					}
					break;
				}
				else
				{
					//				Log.d("No Shape Clicked", "cor-ords: ["+x+", "+y+"]");
				}
			}

		if ( b.getEdgesLeft() < 1 )
		{
			this.gameOver();

		}
		invalidate();
		return false;
	}

	private void gameOver() {
		if ( Scores.HumanScore > Scores.AIScore) 
		{
			updateStatusGameText("Human Won The Game");
			Log.d("nevex", "Human Won The Game!");
		}
		else if ( Scores.HumanScore < Scores.AIScore) 
		{
			updateStatusGameText(aiEngine.getAIName()+" Won The Game");
			Log.d("nevex", aiEngine.getAIName()+" Won The Game!");
		}
		else if ( Scores.HumanScore == Scores.AIScore) 
		{
			updateStatusGameText("The Game Was A Tie");
			Log.d("nevex", "The Game Was A Tie!");
		}	
	}

	private MyShapeDrawable findEdgeSelectedInShapes(Edge e) {
		MyShapeDrawable selectedDrawableEdge = boardShapes[e.getCol()][e.getRow()][e.getEdge()];
		setPrevShapeToNormalColor(selectedDrawableEdge);
		selectedDrawableEdge.getPaint().setColor(Color.YELLOW);
		selectedDrawableEdge.alreadySelected = true;
		return selectedDrawableEdge;
	}

	private void setPrevShapeToNormalColor(MyShapeDrawable pShape) {
		if ( prevSelecetedShape != null )
		{
			prevSelecetedShape.getPaint().setColor(Color.BLUE);
		}
		prevSelecetedShape = pShape;
	}

	public void placeTokenInsideWinnerBox(int col, int row, int player)
	{
		ShapeDrawable circle = new ShapeDrawable(new OvalShape());
		BoxToken circleToken = this.boxBoundaries[col][row];
		circleToken.player = player;
		circle.setBounds(circleToken.tokenRect);
		if ( player == 0 ) 
		{
			circle.getPaint().setColor(Color.RED);
		}
		else {
			circle.getPaint().setColor(Color.BLUE);
		}
		this.fillerShapes.add(circle);
	}

}
