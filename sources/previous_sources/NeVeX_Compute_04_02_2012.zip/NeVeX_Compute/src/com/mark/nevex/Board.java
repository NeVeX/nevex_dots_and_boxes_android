package com.mark.nevex;

import java.util.Observer;
import java.util.Observable;

import com.mark.level.DrawLevel;
import com.mark.level.MyShapeDrawable;
import com.mark.level.Scores;

import android.util.Log;

public class Board  extends Observable {
    private Box box[];
    private MyShapeDrawable shapeBox[];
    private int noOfColums, noOfRows, edgesLeft;
    private int[] score = new int[2];
    private DrawLevel currentDrawLevel;

    public int getEdgesLeft() {
        return edgesLeft;
    }



    public Board(DrawLevel dl, int noOfColumns, int noOfRows) {
    	this.currentDrawLevel = dl;
    	setSize(noOfColumns, noOfRows);
    }
    // returns false if player must go again, true otherwise 
    public boolean acceptMove(MyShapeDrawable shape, Edge edge, int player) {
		if ( !selectEdge(edge.getCol(), edge.getRow(), edge.getEdge()) ) 
		{
			Log.d("nevex", "could not accept move as the edge is already selected.");
		    return false;   // illegal move, player has to go again
		}
		
		// Now we know that an edge was added.
		setChanged();
		edgesLeft--;
		boolean ret = true; // Assume no box completed as default. 
		Box b = getBox(edge.getCol(), edge.getRow());
		if ( b.isComplete() ) {
		    b.setOwner(player);
		    score[player]++;
		    
		    this.currentDrawLevel.placeTokenInsideWinnerBox(edge.getCol(), edge.getRow(), player);
		    
		    if ( player == 0 )
		    {
		    	Scores.HumanScore++;
		    }
		    else {
		    	Scores.AIScore++;
		    }
		    
		    ret = false;
		    Log.d("nevex", "accepted move. player will go again since box is completed.");
		}
		b = getNeighbour(edge.getCol(), edge.getRow(), edge.getEdge());
		if ( b != null && b.isComplete() ) {
	        b.setOwner(player);
		    score[player]++;
		    int[] coOrds = this.getNeighbourCoOrds(edge.getCol(), edge.getRow(), edge.getEdge());
		    this.currentDrawLevel.placeTokenInsideWinnerBox(coOrds[0], coOrds[1], player);
		    
		    if ( player == 0 )
		    {
		    	Scores.HumanScore++;
		    }
		    else {
		    	Scores.AIScore++;
		    }
	            ret = false;
	            Log.d("nevex", "accepted move. player will go again since neighbour box is completed.");
		}
		notifyObservers();
		Log.d("nevex", "Move is returning: "+ret);
		return ret;
    }
    // remote methods needed by players and views
    public boolean isFull()   {
    	return (edgesLeft == 0); 
    }
    
    public int[] getScore()   
    {
    	return score;
    }
    
    public int getOwner(int col, int row)   {
    	return getBox(col, row).getOwner();
    }
    
    public int getSizeX() { return noOfColums; }
    public int getSizeY() { return noOfRows; }
    
    public boolean isSelected(int col, int row, int side) {
    	return getBox(col, row).isPresent(side);
    }
    public String toString() {
		String ret = "";
		Box b;
		for (int row = 0; row < noOfRows; row++) {
		    for (int col = 0; col < noOfColums; col++) {
			b = getBox(col, row);
			ret += (b.isPresent(Edge.NORTH)) ? " -" : " .";
		    }
		    ret += "\n";
		    for (int col = 0; col < noOfColums; col++) {
			b = getBox(col, row);
			ret += (b.isPresent(Edge.WEST)) ? "|" : ".";
			ret += (b.isComplete()) ? b.getOwner() : " "; 
		    }
		    ret += (getBox(noOfColums - 1, row).isPresent(Edge.EAST)) ? "|" : ".";
		    ret += "\n";
		}
		for (int col = 0; col < noOfColums; col++) {
		    ret += (getBox(col, noOfRows - 1).isPresent(Edge.SOUTH)) ? " -" : " .";
		}
		ret += "\n";
		return ret;
    }
    // private helper methods
    private void setSize(int noOfColumns, int noOfRows) {
		this.noOfColums = noOfColumns;
		this.noOfRows = noOfRows;
		box = new Box[noOfColums * noOfRows];
//		Log.d("nevex", "set size of boxes on board to "+box.length);
		edgesLeft = noOfColums * (noOfRows + 1) + noOfRows * (noOfColums + 1);
		init();
    }
    private boolean selectEdge(int col, int row, int side) {
		if ( !getBox(col, row).selectEdge(side) ) {
		    return false;
		}
		Box b = getNeighbour(col, row, side);
		
		if ( b != null ) {
		    if ( ! (b.selectEdge(Edges.oppositeSide(side))) )
			System.err.println("There is a problem with overlapping edges");
		}
		return true;
    }
    
    private void init() {
		for (int i = 0; i < box.length; i++) 
		    box[i] = new Box();
    }
    
    private Box getBox(int x, int y) {
//    	Log.d("nevex", "getting box for "+x+", "+y+". Returning box: "+(y * noOfColums + x));
    	return box[y * noOfColums + x];
    }
	     
    private boolean isLegal(int x, int y) {
    	return (x >= 0 && x < noOfColums && y >= 0 && y < noOfRows);
    }
    
    public int[] getNeighbourCoOrds(int x, int y, int side) {
		int edge;
		if (side == Edge.NORTH) 
		    y -= 1;
		else if (side == Edge.SOUTH) 
		    y += 1;
		else if (side == Edge.EAST) 
		    x += 1;
		else if (side == Edge.WEST) 
		    x -= 1;
		if (!isLegal(x,y)) {
			return null;
		}
		return new int[]{x, y};
    }
    
    public Box getNeighbour(int x, int y, int side) {
		int edge;
		if (side == Edge.NORTH) 
		    y -= 1;
		else if (side == Edge.SOUTH) 
		    y += 1;
		else if (side == Edge.EAST) 
		    x += 1;
		else if (side == Edge.WEST) 
		    x -= 1;
		if (!isLegal(x,y)) {
			return null;
		}
		return getBox(x, y);
    }
    
    public int[] getNeighbourEdgeAndCoOrds(int x, int y, int side) {
		if (side == Edge.NORTH) 
		    y -= 1;
		else if (side == Edge.SOUTH) 
		    y += 1;
		else if (side == Edge.EAST) 
		    x += 1;
		else if (side == Edge.WEST) 
		    x -= 1;
		if (!isLegal(x,y)) {
			return null;
		}
		Log.d("nevex", "returning neighbour box: "+x+", "+y+", "+Edges.oppositeSide(side));
		return new int[]{x, y, Edges.oppositeSide(side)};
    }
}
	    

