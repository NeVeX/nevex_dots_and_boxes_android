package com.mark.nevex;

public interface AIEngine {

	public Edge AI_Make_Move();
	public Edge pickEdge();
	public String getAIName();
	
}
