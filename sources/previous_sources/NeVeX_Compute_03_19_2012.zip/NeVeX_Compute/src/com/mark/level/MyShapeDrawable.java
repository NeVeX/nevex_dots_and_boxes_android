package com.mark.level;

import com.mark.nevex.Board;
import com.mark.nevex.Box;
import com.mark.nevex.Edge;

import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RectShape;
import android.util.Log;

public class MyShapeDrawable extends ShapeDrawable {
	
	public MyShapeDrawable(RectShape rectShape) {
		super(rectShape);
		// TODO Auto-generated constructor stub
	}

	public Edge myEdge, neighbourEdge;
	public boolean alreadySelected = false;
	
	public void setEdge(int row, int col, int edge, Board b)
	{
		myEdge = new Edge(col, row, edge);
		int[] box = b.getNeighbourEdgeAndCoOrds(col, row, edge);
		
		Log.d("nevex", "Edge for shape: "+myEdge.getCol()+", "+myEdge.getRow()+", "+myEdge.getEdge());
		if ( box != null ) 
		{
			neighbourEdge = new Edge(box[0], box[1], box[2]);
			Log.d("nevex", "Edge for shape: "+neighbourEdge.getCol()+", "+neighbourEdge.getRow()+", "+neighbourEdge.getEdge());
		}
		
		
	}
	
	public Edge[] getEdges()
	{
		return null;
		
	}
	
//	private boolean edge[] = new boolean[4];
//    private int owner = -1;
//    /** Returns true if the side of this box was not 
//     * selected before, flase if it was*/
//    public boolean selectEdge(int side) {
//	if (edge[side])
//	    return false;
//	edge[side] = true;
//	return true;
//    }
//    /** Returns true if the named side of this box is present. */
//    public boolean isPresent(int side) {
//    	return edge[side];
//    }
//    /** Returns true of this box has four complete edges. */
//    public boolean isComplete() {
//    	return (edge[0] && edge[1] && edge[2] && edge[3]);
//    }
//    /** Sets the owner of this box. */
//    public void setOwner(int player) {
//		if (owner != -1) 
//		    System.err.println("BUG: Setting owner of an already owned box, player = " + player); 
//		owner = player;
//	    }
//	    /** Returns th eowner of this box, see {@link boxit.RmtBoard#PLAYER_1}, {@link boxit.RmtBoard#PLAYER_2}. */
//	    public int getOwner() { 
//		return owner;
//    }

}
