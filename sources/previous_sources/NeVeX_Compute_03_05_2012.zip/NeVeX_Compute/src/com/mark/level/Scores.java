package com.mark.level;

import java.util.Observable;

public class Scores extends Observable {

	public static int HumanScore = 0;
	public static int AIScore = 0;
}
