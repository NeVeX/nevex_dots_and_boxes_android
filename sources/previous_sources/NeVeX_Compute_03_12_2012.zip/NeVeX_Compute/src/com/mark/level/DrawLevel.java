package com.mark.level;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.graphics.drawable.shapes.RectShape;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.TextView;

import com.mark.GameManager;
import com.mark.R;
import com.mark.nevex.AIEngine;
import com.mark.nevex.Board;
import com.mark.nevex.Edge;
import com.mark.nevex.Edges;
import com.mark.nevex.NeVeX;
import com.mark.nevex.Viper;

public class DrawLevel extends View implements OnTouchListener {

	private int lineWidth = 100;
	private int lineHeight = 20;
	private int startX = 10;
	private int startY = 10;
	private int boardRows, boardColumns;
	
	private ArrayList<MyShapeDrawable> currentShapes = new ArrayList<MyShapeDrawable>();
	private MyShapeDrawable[][][] boardShapes;
	private Board b;
	private BoxToken[][] boxBoundaries;
	private AIEngine aiEngine;
//	private NeVeX nevex;
//	private Viper viper;
	private MyShapeDrawable prevSelecetedShape;
//	private int currentCol;
////	
////     public DrawLevel(Context context) {
////	     super(context);
////	     this.createRectShape();	     
////     }
//	private int currentRow;
	private boolean nevexComputing;
	private boolean gameJustStated;
	private ArrayList<ShapeDrawable> fillerShapes = new ArrayList<ShapeDrawable>();
     
	protected void onFinishInflate()
	{
//		super.onFinishInflate();
		this.resetBoard();
	}
	
     private MyShapeDrawable createRectShape(int x, int y, boolean vertical, int row, int col, int edge)
     {
    	 Log.d("nevex", "creating shape with the following dimensions: "+x+", "+y+", "+vertical+", "+row+", "+col+", "+edge);
    	 MyShapeDrawable drawableLine;
	     int width = lineWidth;
	     int height = lineHeight;

	     drawableLine = new MyShapeDrawable(new RectShape());
	     drawableLine.getPaint().setColor(Color.TRANSPARENT);
	     if ( vertical )
	     {
//	    	 drawableLine.edge = Edge.WEST;
	    	 drawableLine.setEdge(col, row, edge, b);
	    	 drawableLine.setBounds(x, y+20, x + height, y + width);
	     }
	     else
	     {
//	    	 drawableLine.edge = Edge.NORTH;
	    	 drawableLine.setEdge(col, row, edge, b);
	    	 drawableLine.setBounds(x+20, y, x + width, y + height);
	    	 
	    	 ShapeDrawable circle = new ShapeDrawable(new OvalShape());
	    	 circle.setBounds(x + width + 2, y, x + width + 18, y + height );
	    	 circle.getPaint().setColor(Color.WHITE);
	    	 fillerShapes.add(circle);
	    	 
	     }

	     Log.d("nevex", "adding new shape for : row "+drawableLine.myEdge.getRow()+", col "+drawableLine.myEdge.getCol()+" , edge "+drawableLine.myEdge.getEdge());
	     currentShapes.add(drawableLine);
	     
	     // add to normal 

	     // also add this to the place where this line is shared
	     
	     return drawableLine;
     }
     
     public DrawLevel(Context context, AttributeSet as)
     {
    	 super(context, as);
//    	 this.setLayoutParams(new LayoutParams(300, 300));
    	 gameJustStated = true;
    	 boardRows = GameManager.Rows;
    	 boardColumns = GameManager.Columns;
    	 boardShapes = new MyShapeDrawable[boardColumns][boardRows][4];
    	 boxBoundaries = new BoxToken[boardColumns][boardRows];
    	 b = new Board(this, boardColumns, boardRows);
    	 
    	 Log.d("nevex", "new board is: \n"+b.toString());
    	 
    	 
    	 if ( GameManager.aiEngine.equals("NeVeX"))
    	 {
    		 
    		 aiEngine = new NeVeX(b);
    	 }
    	 else
    	 {
    		 aiEngine = new Viper(b);
    	 }
    	 

    	 int gap = 0;
    	 int prevX = startX;
    	 int prevY = startY;
    	 int currentRow = 0;
    	 int currentCol = 0;

    	 for ( int rows = 0; rows < boardRows; rows++)
    	 {
    		
    		 
	    	 for (int i = 0; i < boardColumns; i++)
	    	 { 
	    		 Rect boxBounds = new Rect();
	    		
		    	 ShapeDrawable circle = new ShapeDrawable(new OvalShape());
		    	 circle.setBounds(prevX, prevY, prevX  + 18, prevY + lineHeight );
		    	 circle.getPaint().setColor(Color.WHITE);
		    	 fillerShapes.add(circle);
	    		 
	    		 
	    		 MyShapeDrawable newDrawableLine = this.createRectShape(prevX, prevY, false, currentCol, currentRow, Edge.NORTH);
	    		 boardShapes[currentCol][currentRow][Edge.NORTH] = newDrawableLine;
	    		 
	    		 boxBounds.top = newDrawableLine.getBounds().bottom;
	    		 boxBounds.left = newDrawableLine.getBounds().left;
	    		 boxBounds.right = newDrawableLine.getBounds().right;
	    		 boxBounds.bottom = boxBounds.top + ( lineWidth - lineHeight);
	    		 BoxToken bt = new BoxToken();
	    		 bt.tokenRect = boxBounds;
	    		 this.boxBoundaries[i][rows] = bt;
	    		 Log.d("box", "["+i+"]["+rows+"] -- "+boxBounds.left+","+boxBounds.top+","+boxBounds.right+","+boxBounds.bottom);
	    		 
	    		 if ( currentRow > 0 ) {
	    			 boardShapes[currentCol][currentRow - 1][Edge.SOUTH] = newDrawableLine;
	    		 }
	    		 
	    		 prevX = prevX + lineWidth + gap;
	    		 currentCol++;
	    		 
	    	     
	    	 }
	    	 
	    	 prevX = startX;
	    	 currentCol = 0;
	    	 for (int c = 0; c <= boardColumns; c++)
	    	 {
	    		 
	    		 if ( c == boardColumns ) 
	    		 {
	    			 // last column is also the previous column
	    			 MyShapeDrawable newDrawableLine = this.createRectShape(prevX, prevY, true, currentCol - 1, currentRow, Edge.EAST);
	    			 boardShapes[currentCol - 1][currentRow][Edge.EAST] = newDrawableLine;
	    		 }
	    		 else 
	    		 {
	    			 MyShapeDrawable newDrawableLine = this.createRectShape(prevX, prevY, true, currentCol, currentRow, Edge.WEST);
	    			 boardShapes[currentCol][currentRow][Edge.WEST] = newDrawableLine;
		    		 if ( currentCol > 0 ) {
		    			 boardShapes[currentCol - 1][currentRow][Edge.EAST] = newDrawableLine;
		    		 }
	    		 }
	    		 
	    		 prevX = prevX + lineWidth + gap;
	    		 currentCol++;

	    	 }
	    	 
	    	 prevX = startX;
	    	 prevY = startY + ((lineWidth) * ( rows + 1)) + gap;
	    	 
	    	 
	    	 // draw last line row
	    	 if ( rows == boardRows - 1)
	    	 {
	    		 
	    		 ShapeDrawable circle = new ShapeDrawable(new OvalShape());
		    	 circle.setBounds(prevX, prevY, prevX  + 18, prevY + lineHeight );
		    	 circle.getPaint().setColor(Color.WHITE);
		    	 fillerShapes.add(circle);
	    		 
	    		 
	    		 currentCol = 0;
//	    		 currentRow++;
	    		 // last row is also the previous row
		    	 for (int i = 0; i < boardColumns; i++)
		    	 {
		    		 MyShapeDrawable newDrawableLine = this.createRectShape(prevX, prevY, false, currentCol, currentRow, Edge.SOUTH);
	    			 boardShapes[currentCol][currentRow][Edge.SOUTH] = newDrawableLine;
		    		 prevX = prevX + lineWidth + gap;
		    		 currentCol++;
		    	 }
	    	 }
	    	 currentRow++;
	    	 currentCol = 0;
	    	 
    	 }
    	 
    	 
    	 setOnTouchListener(this);
    	 
     }
	
     private void resetBoard() {
    	 Scores.HumanScore = Scores.AIScore = 0;
    	 
    	 
		
	}

	protected void onDraw(Canvas canvas) {
		setUpTextViews();
    	 for (MyShapeDrawable d : currentShapes)
    	 {
    		 if (d.isVisible())
    		 {
    			 d.draw(canvas);
    		 }
    	 }
    	 
    	 for ( ShapeDrawable c: fillerShapes )
    	 {
    		 c.draw(canvas);
    	 }
    	 
    	 Log.d("nevex", "Human Score: "+Scores.HumanScore);
    	 Log.d("nevex", "NeVeX Score: "+Scores.AIScore);
    	 setUpTextViews();
    	 if (gameJustStated )
		 {
    		 updateStatusGameText("Human, Make Your Move.");
    		 gameJustStated = false;
		 }
    	 if ( b.getEdgesLeft() <= 0 ) 
    	 {
    		 if ( Scores.HumanScore > Scores.AIScore) 
    		 {
    			 updateStatusGameText("Human Won The Game");
    			 Log.d("nevex", "Human Won The Game!");
    		 }
    		 else if ( Scores.HumanScore < Scores.AIScore) 
    		 {
    			 updateStatusGameText(aiEngine.getAIName()+" Won The Game");
    			 Log.d("nevex", aiEngine.getAIName()+" Won The Game!");
    		 }
    		 else if ( Scores.HumanScore < Scores.AIScore) 
    		 {
    			 updateStatusGameText("The Game Was A Tie");
    			 Log.d("nevex", "The Game Was A Tie!");
    		 }
    		 
    		 
    		 
    		 
    	 }

     }
     
 	public void setUpTextViews() {
 		View v = (View) this.getRootView();
 		
		TextView tv = (TextView) v.findViewById(R.id.scoresHumanoidText);
        TextView tv2 = (TextView) v.findViewById(R.id.scoresNeVeXText);
        
        tv.setText("Human Score: "+Scores.HumanScore);
        tv2.setText(aiEngine.getAIName()+" Score: "+Scores.AIScore);
	}
 	
 	private void updateStatusGameText(String text)
 	{
 		View v = this.getRootView();
 		TextView tv = (TextView) v.findViewById(R.id.statusGameText);
 		tv.setText(text);

 	}

	public void onClick(View arg0) {
//		Log.d("DrawLevel", "Something Somewhere Was Clicked....");
//		currentShapes.get(0).setVisible(false, false);
		}

	public boolean onTouch(View v, MotionEvent event) {
		
		int x = (int) event.getX();
		int y = (int) event.getY();
		
		
		if ( !this.nevexComputing && b.getEdgesLeft() > 0 )
		for (MyShapeDrawable d : currentShapes)
		{
			if ( d.getBounds().contains(x, y) && !d.alreadySelected)
			{
//				Log.d("Shape Clicked", "drawable line touched with cor-ords: ["+x+", "+y+"]");
				Log.d("nevex", "Shape with edge selected: "+d.myEdge.getCol()+", "+d.myEdge.getRow()+" ,"+d.myEdge.getEdge());
				if (d.getPaint().getColor() == Color.TRANSPARENT)
				{
					d.getPaint().setColor(Color.RED);
					d.alreadySelected = true;
					setPrevShapeToNormalColor(null);
					invalidate();
				}
				
				if (b.acceptMove(d, d.myEdge, 0) )
				{
					// player move valid, calling on the AI engine now
					updateStatusGameText(aiEngine.getAIName()+" Is Computing....");
					this.nevexComputing = true;
					Log.d("nevex", "player move over");
					Log.d("nevex", "nevex is thinking.....");
					Edge e = aiEngine.pickEdge();
					d = findEdgeSelectedInShapes(e);
					Log.d("nevex", "nevex has made it's move: "+e.getCol()+", "+e.getRow()+" ,"+e.getEdge());
					
					while ( !b.acceptMove(d, e, 1) && b.getEdgesLeft() > 0)
					{
						Log.d("nevex", "nevex is thinking again.....");
						Log.d("nevex", "board accepted ths move by nevex. Finding shape to select on this move.");
						invalidate();
						e = aiEngine.pickEdge();
						d = findEdgeSelectedInShapes(e);
						Log.d("nevex", "nevex has made it's move: "+e.getRow()+", "+e.getCol()+" ,"+e.getEdge());
						
					}
					Log.d("nevex", "board accepted ths move by nevex. Finding last shape to select on this move.");
					findEdgeSelectedInShapes(e);
					invalidate();
					Log.d("nevex", "nevex move over");
					this.nevexComputing = false;
					updateStatusGameText(aiEngine.getAIName()+" Made Move. Human, Make Your Move.");
				}
				else
				{
					// human player got a box
//					placeTokenInsideWinnerBox(d);
					updateStatusGameText("Human, Again, Make Your Move.");
					Log.d("nevex", "player gets to go again");
				}
				break;
			}
			else
			{
//				Log.d("No Shape Clicked", "cor-ords: ["+x+", "+y+"]");
			}
		}

		invalidate();
		return false;
	}



	private MyShapeDrawable findEdgeSelectedInShapes(Edge e) {
		MyShapeDrawable selectedDrawableEdge = boardShapes[e.getCol()][e.getRow()][e.getEdge()];
		setPrevShapeToNormalColor(selectedDrawableEdge);
		selectedDrawableEdge.getPaint().setColor(Color.YELLOW);
		selectedDrawableEdge.alreadySelected = true;
		return selectedDrawableEdge;
	}
	
	private void setPrevShapeToNormalColor(MyShapeDrawable pShape) {
		if ( prevSelecetedShape != null )
		{
			prevSelecetedShape.getPaint().setColor(Color.BLUE);
		}
		prevSelecetedShape = pShape;
	}
	
	public void placeTokenInsideWinnerBox(int col, int row, int player)
	{
		ShapeDrawable circle = new ShapeDrawable(new OvalShape());
		BoxToken circleToken = this.boxBoundaries[col][row];
		circleToken.player = player;
		circle.setBounds(circleToken.tokenRect);
		if ( player == 0 ) 
		{
			circle.getPaint().setColor(Color.RED);
		}
		else {
			circle.getPaint().setColor(Color.BLUE);
		}
		this.fillerShapes.add(circle);
	}
	
}
