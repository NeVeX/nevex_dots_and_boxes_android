package com.mark.level;

import android.graphics.Rect;

public class BoxToken {

	public Rect tokenRect;
	public int player;
	
}
