package com.mark.level;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.graphics.drawable.shapes.RectShape;
import android.util.AttributeSet;
import android.util.Log;

import com.mark.nevex.Board;
import com.mark.nevex.Edge;

public class ShapeFactory {

	BoxToken[][] boxBoundaries;
	MyShapeDrawable[][][] boardShapes;
	public ArrayList<MyShapeDrawable> currentShapes = new ArrayList<MyShapeDrawable>();
	public ArrayList<ShapeDrawable> fillerShapes = new ArrayList<ShapeDrawable>();
	private Board board;
	
	private int debugCirclesDrawn, debugLinesDrawn;
	
	public ShapeFactory(Board b)
	{
		this.board = b;
		debugCirclesDrawn = debugLinesDrawn = 0;
	}
	
	public void DrawBoard()
	{
		this.drawRowsAndColumns();
		this.drawGameBorder();
	}

	private void drawRowsAndColumns() {
		int prevX, prevY;
		prevX = prevY = determineStartCoOrds();

		int currentRow = 0;
		int currentCol = 0;
		
		boardShapes = new MyShapeDrawable[BoardSettings.boardColumns][BoardSettings.boardRows][4];
		boxBoundaries = new BoxToken[BoardSettings.boardColumns][BoardSettings.boardRows];

		for ( int rows = 0; rows < BoardSettings.boardRows; rows++)
		{
			
			createOneRowOfHorizontalShapes(prevX, prevY, currentRow, currentCol,rows);

			prevX = determineStartCoOrds();
			currentCol = 0;
			
			prevY = createOneRowOfVerticalShapes(prevX, prevY, currentRow, currentCol);
			prevX = determineStartCoOrds();

			currentCol = 0;
			// Check if we are in the last row
			if ( rows == BoardSettings.boardRows - 1)
			{
				createOneRowOfHorizontalShapes(prevX, prevY, currentRow, currentCol, rows);
			}
			currentRow++;
		}
	}

	private int createOneRowOfVerticalShapes(int prevX, int prevY, int currentRow, int currentCol) {
		int columnX = prevX;
		for (int c = 0; c <= BoardSettings.boardColumns; c++)
		{
			columnX = this.shapeCreatorForColumns(BoardSettings.boardColumns, columnX, prevY, currentRow, currentCol, c);
			currentCol++;
		}
		return columnX;
	}

	private void createOneRowOfHorizontalShapes(int prevX, int prevY, int currentRow, int currentCol, int rows) {
		int rowX = prevX;
		for (int i = 0; i < BoardSettings.boardColumns; i++)
		{ 
			rowX = this.shapeCreatorForRows(rowX, prevY, currentRow, currentCol, rows, i, false);
			currentCol++;
		}
	}

	private int determineStartCoOrds() {
		return BoardSettings.boardBorderWidth + BoardSettings.borderGapToBoard;
	}


	private int shapeCreatorForColumns(int boardColumns, int prevX, int prevY, int currentRow, int currentCol, int c) {
		MyShapeDrawable newDrawableLine;
		if ( c == boardColumns ) 
		{
			// last column is also the previous column
			newDrawableLine = this.createRectShape(prevX, prevY, true, currentCol - 1, currentRow, Edge.EAST);
			boardShapes[currentCol - 1][currentRow][Edge.EAST] = newDrawableLine;
			
		}
		else 
		{
			newDrawableLine = this.createRectShape(prevX, prevY, true, currentCol, currentRow, Edge.WEST);
			boardShapes[currentCol][currentRow][Edge.WEST] = newDrawableLine;
			if ( currentCol > 0 ) {
				boardShapes[currentCol - 1][currentRow][Edge.EAST] = newDrawableLine;
			}
		}
		return newDrawableLine.getBounds().right;
		
	}

	private int shapeCreatorForRows(int prevX, int prevY, int currentRow,int currentCol, int rows, int i, boolean isLastRow) {
		if ( currentCol == 0 )
		{
			// in first column, so draw the first circle also
			this.createAndAddNewLayoutBoardCircle(BoardSettings.boardStartX, prevY);
		}
		this.createAndAddNewLayoutBoardCircle(prevX + BoardSettings.lineWidth, prevY);
		
		MyShapeDrawable newDrawableLine = this.createRectShape(prevX, prevY, false, currentCol, currentRow, Edge.NORTH);
		if (isLastRow)
		{
			boardShapes[currentCol][currentRow][Edge.SOUTH] = newDrawableLine;
		}
		else
		{
			boardShapes[currentCol][currentRow][Edge.NORTH] = newDrawableLine;
			if ( currentRow > 0 ) {
				boardShapes[currentCol][currentRow - 1][Edge.SOUTH] = newDrawableLine;
			}
		}
		addGameBoxDefinitions(rows, i, newDrawableLine);
		return newDrawableLine.getBounds().right;
	}

	private void addGameBoxDefinitions(int rows, int i, MyShapeDrawable newDrawableLine) {
		Rect boxBounds = new Rect();
		boxBounds.top = newDrawableLine.getBounds().bottom;
		boxBounds.left = newDrawableLine.getBounds().left;
		boxBounds.right = newDrawableLine.getBounds().right;
		boxBounds.bottom = boxBounds.top + ( BoardSettings.lineWidth - BoardSettings.lineHeight);
		BoxToken bt = new BoxToken();
		bt.tokenRect = boxBounds;
		this.boxBoundaries[i][rows] = bt;
		Log.d("box", "["+i+"]["+rows+"] -- "+boxBounds.left+","+boxBounds.top+","+boxBounds.right+","+boxBounds.bottom);
	}
	
	private void createAndAddNewLayoutBoardCircle(int prevX, int prevY) {
//		ShapeDrawable circle = new ShapeDrawable(new OvalShape());
//		circle.setBounds(prevX + BoardSettings.circleStartBounds, 
//				prevY + BoardSettings.circleStartBounds, 
//				prevX + BoardSettings.circleEndBounds, 
//				prevY + BoardSettings.circleEndBounds );
//		circle.getPaint().setColor(Color.WHITE);
//		fillerShapes.add(circle);
//		debugCirclesDrawn++;
	}
	
	private void drawGameBorder() {
		ShapeDrawable borderTop = new ShapeDrawable(new RectShape());
		borderTop.setBounds(0, 0, (int)BoardSettings.myCanvasWidth, BoardSettings.boardBorderWidth);

		ShapeDrawable borderBottom = new ShapeDrawable(new RectShape());
		borderBottom.setBounds(0, (int)BoardSettings.myCanvasHeight - BoardSettings.boardBorderWidth, (int)BoardSettings.myCanvasWidth, (int)BoardSettings.myCanvasHeight);

		ShapeDrawable borderLeft = new ShapeDrawable(new RectShape());
		borderLeft.setBounds(0, 0, BoardSettings.boardBorderWidth, (int)BoardSettings.myCanvasHeight - BoardSettings.boardBorderWidth);

		ShapeDrawable borderRight = new ShapeDrawable(new RectShape());
		borderRight.setBounds((int)BoardSettings.myCanvasWidth - BoardSettings.boardBorderWidth, 0, (int)BoardSettings.myCanvasWidth , (int)BoardSettings.myCanvasHeight);

		borderTop.getPaint().setColor(Color.WHITE);
		borderBottom.getPaint().setColor(Color.WHITE);
		borderLeft.getPaint().setColor(Color.WHITE);
		borderRight.getPaint().setColor(Color.WHITE);
		
		fillerShapes.add(borderLeft);
		fillerShapes.add(borderTop);
		fillerShapes.add(borderRight);
		fillerShapes.add(borderBottom);
	}
	
	private MyShapeDrawable createRectShape(int x, int y, boolean vertical, int col, int row, int edge)
	{
		Log.d("nevex", "creating shape with the following dimensions: "+x+", "+y+", "+vertical+", "+col+", "+row+", "+edge);
		MyShapeDrawable drawableLine;

		drawableLine = new MyShapeDrawable(new RectShape());
		drawableLine.getPaint().setColor(Color.TRANSPARENT);
		if ( vertical )
		{
			drawableLine.setEdge(row, col, edge, board);
			drawableLine.setBounds(x, y + BoardSettings.lineGap, x + BoardSettings.lineHeight, y + BoardSettings.lineWidth);
		}
		else
		{
			drawableLine.setEdge(row, col, edge, board);
			drawableLine.setBounds(x + BoardSettings.lineGap, y, x + BoardSettings.lineWidth, y + BoardSettings.lineHeight);

		}
		Log.d("nevex", "adding new shape for : row "+drawableLine.myEdge.getRow()+", col "+drawableLine.myEdge.getCol()+" , edge "+drawableLine.myEdge.getEdge());
		currentShapes.add(drawableLine);
		debugLinesDrawn++;
		return drawableLine;
	}

	
}
