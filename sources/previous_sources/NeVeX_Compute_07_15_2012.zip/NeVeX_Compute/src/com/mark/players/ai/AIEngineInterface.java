package com.mark.players.ai;

import com.mark.board.Edge;

public interface AIEngineInterface {

//	public Edge AI_Make_Move();
	public Edge aiMakeMove();
	public String getAIName();
	
	
}
