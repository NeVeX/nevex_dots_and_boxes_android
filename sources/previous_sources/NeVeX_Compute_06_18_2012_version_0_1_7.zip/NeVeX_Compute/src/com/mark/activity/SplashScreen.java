package com.mark.activity;

import java.util.Timer;
import java.util.TimerTask;

import com.mark.R;
import com.mark.app.ApplicationSettings;
import com.mark.app.Colors;
import com.mark.game.GameBoardSettings;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.opengl.Visibility;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.TextView;

public class SplashScreen extends Activity {
	Handler mhandler = new Handler();
	
	private Runnable myRunner = new Runnable() {
		public void run() {
			enableClickText();
		}
	};
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_screen);
        this.displayVersionName();
        new Colors(getResources());
        
        // schedule the runner to update the text
        mhandler.postDelayed(myRunner, 3000);

	}

	public void enableClickText() {
		TextView touchText = (TextView) findViewById(R.id.touchScreenSplashScreenText);
		touchText.setVisibility(View.VISIBLE);
		
	}

	public void splashScreenClick(View v)
	{
		// stop my runner from updating
		mhandler.removeCallbacks(myRunner);
		// start the main menu activity
		Intent myIntent = new Intent(v.getContext(), MainMenuActivity.class);
		startActivity(myIntent);
	}
	
	private void displayVersionName() {
	    PackageInfo packageInfo;
	    try {
	        packageInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
	        ApplicationSettings.APP_VERSION_STRING = "v " + packageInfo.versionName;
	    } catch (NameNotFoundException e) {
	        e.printStackTrace();
	    }
	    
	    TextView tv = (TextView) findViewById(R.id.splashVersionAppNumber);
	    tv.setText(ApplicationSettings.APP_VERSION_STRING);
	}
	
	
}
