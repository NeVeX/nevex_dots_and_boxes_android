package com.mark.level;

public class BoardSettings {

	public static int lineWidth = 100;
	public static int lineHeight = 20;
	public static int boardBorderWidth = 10;
	public static int borderGapToBoard = 20;
	public static int lineGap = 20;
	public static int getCircleStartBounds() {
//		return (int) ((int)lineGap * 0.1);
		return 2;
	}
	

	public static int getCircleEndBounds() {
//		return (int) ((int)lineGap * 0.9);
		return 18;
	}

//	public static int boardPadding = 50;
	public static int boardRows, boardColumns;
	public static int myCanvasWidth, myCanvasHeight;
	public static int boardWindowYOffset;
	
	public static void calculateDimensions() {
		myCanvasWidth = (BoardSettings.boardColumns * BoardSettings.lineWidth) 
				+ ( (BoardSettings.boardColumns + 1) * BoardSettings.lineHeight)
				+ (BoardSettings.boardBorderWidth * 2) 
				+ ( borderGapToBoard * 2 );
		
		myCanvasHeight = (BoardSettings.boardRows * BoardSettings.lineWidth) 
				+ ( (BoardSettings.boardRows + 1) * BoardSettings.lineHeight) 
				+ ( BoardSettings.boardBorderWidth * 2) 
				+ ( borderGapToBoard * 2 );


//		myCanvasWidth = (BoardSettings.boardColumns * BoardSettings.lineWidth) 
////				+ ( (BoardSettings.boardColumns + 1) * BoardSettings.lineHeight)
//				+ (BoardSettings.boardBorderWidth * 2) 
//				+ ( borderGapToBoard * 2 )
//				+ lineGap;
//		
//		
//		myCanvasHeight = (BoardSettings.boardRows * BoardSettings.lineWidth) 
////				+ ( (BoardSettings.boardRows + 1) * BoardSettings.lineHeight) 
//				+ ( BoardSettings.boardBorderWidth * 2) 
//				+ ( borderGapToBoard * 2 )
//				+ lineGap;

		
	}
	
//	public BoardSettings()
//	{
//		boardStartX = gameBorderWidth + lineGap;
//		boardStartY = boardStartX;
//		circleStartBounds = (int) ((int) lineGap * 0.3);
//		circleEndBounds = (int) ((int) lineGap * 0.7);
//	}
	
}
