package com.mark;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class MainMenuActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_menu);
        
        Spinner s = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter adapter = ArrayAdapter.createFromResource(
                this, R.array.aiEngines, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(adapter);
        
        Spinner rowSpinner = (Spinner) findViewById(R.id.spinnerRows);
        ArrayAdapter rowAdapter = ArrayAdapter.createFromResource(
                this, R.array.boardSizes, android.R.layout.simple_spinner_item);
        rowAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        rowSpinner.setAdapter(rowAdapter);
        
        Spinner colSpinner = (Spinner) findViewById(R.id.spinnerColumns);
        ArrayAdapter colAdapter = ArrayAdapter.createFromResource(
                this, R.array.boardSizes, android.R.layout.simple_spinner_item);
        colAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        colSpinner.setAdapter(colAdapter);
        
    }
    
    
    public void startNewGame(View v)
    {
    	Spinner s = (Spinner) findViewById(R.id.spinner);
    	String ai = (String) s.getSelectedItem();
    	
    	Spinner rowSpinner = (Spinner) findViewById(R.id.spinnerRows);
    	Spinner colSpinner = (Spinner) findViewById(R.id.spinnerColumns);
    	
        GameActivity.Rows = Integer.parseInt((String) rowSpinner.getSelectedItem());
        GameActivity.Columns = Integer.parseInt((String) colSpinner.getSelectedItem());
    	
    	Intent myIntent = new Intent(v.getContext(), GameActivity.class);
 
    	if ( ai.equals("NeVeX"))
    	{
    		myIntent.putExtra("AI", "NeVeX");
    		
    		startActivity(myIntent);
    	}
    	else
    	{
    		myIntent.putExtra("AI", "Viper");
    		startActivity(myIntent);
    	}
    	
    }
	
}

