package com.mark.level;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.graphics.drawable.shapes.RectShape;
import android.util.AttributeSet;
import android.util.Log;

import com.mark.nevex.Board;
import com.mark.nevex.Edge;

public class ShapeFactory {

	BoxToken[][] boxBoundaries;
	MyShapeDrawable[][][] boardShapes;
	public ArrayList<MyShapeDrawable> currentShapes = new ArrayList<MyShapeDrawable>();
	public ArrayList<ShapeDrawable> fillerShapes = new ArrayList<ShapeDrawable>();
	private Board board;
	
	private int debugCirclesDrawn, debugLinesDrawn;
	
	public ShapeFactory(Board b)
	{
		this.board = b;
		debugCirclesDrawn = debugLinesDrawn = 0;
	}
	
	public void DrawBoard()
	{
		
		int boardRows = BoardSettings.boardRows;
		int boardColumns = BoardSettings.boardColumns;
		
		int prevX = BoardSettings.boardStartX;
		int prevY = BoardSettings.boardStartY;

		int currentRow = 0;
		int currentCol = 0;
		
		boardShapes = new MyShapeDrawable[BoardSettings.boardColumns][BoardSettings.boardRows][4];
		boxBoundaries = new BoxToken[BoardSettings.boardColumns][BoardSettings.boardRows];

		for ( int rows = 0; rows < boardRows; rows++)
		{
			for (int i = 0; i < boardColumns; i++)
			{ 
				Rect boxBounds = new Rect();
				MyShapeDrawable newDrawableLine = this.createRectShape(prevX, prevY, false, currentCol, currentRow, Edge.NORTH);
				boardShapes[currentCol][currentRow][Edge.NORTH] = newDrawableLine;

				boxBounds.top = newDrawableLine.getBounds().bottom;
				boxBounds.left = newDrawableLine.getBounds().left;
				boxBounds.right = newDrawableLine.getBounds().right;
				boxBounds.bottom = boxBounds.top + ( BoardSettings.lineWidth - BoardSettings.lineHeight);
				BoxToken bt = new BoxToken();
				bt.tokenRect = boxBounds;
				this.boxBoundaries[i][rows] = bt;
				Log.d("box", "["+i+"]["+rows+"] -- "+boxBounds.left+","+boxBounds.top+","+boxBounds.right+","+boxBounds.bottom);

				if ( currentRow > 0 ) {
					boardShapes[currentCol][currentRow - 1][Edge.SOUTH] = newDrawableLine;
				}

				prevX = prevX + BoardSettings.lineWidth;
				currentCol++;


			}

			prevX = BoardSettings.boardStartX;
			currentCol = 0;
			for (int c = 0; c <= boardColumns; c++)
			{

				if ( c == boardColumns ) 
				{
					// last column is also the previous column
					MyShapeDrawable newDrawableLine = this.createRectShape(prevX, prevY, true, currentCol - 1, currentRow, Edge.EAST);
					boardShapes[currentCol - 1][currentRow][Edge.EAST] = newDrawableLine;
				}
				else 
				{
					MyShapeDrawable newDrawableLine = this.createRectShape(prevX, prevY, true, currentCol, currentRow, Edge.WEST);
					boardShapes[currentCol][currentRow][Edge.WEST] = newDrawableLine;
					if ( currentCol > 0 ) {
						boardShapes[currentCol - 1][currentRow][Edge.EAST] = newDrawableLine;
					}
				}

				prevX = prevX + BoardSettings.lineWidth;
				currentCol++;

			}

			prevX = BoardSettings.boardStartX;
			prevY = BoardSettings.boardStartY + ((BoardSettings.lineWidth) * ( rows + 1));


			// draw last line row
			if ( rows == boardRows - 1)
			{

//				createAndAddNewLayoutBoardCircle(prevX, prevY);

				currentCol = 0;
				//	    		 currentRow++;
				// last row is also the previous row
				for (int i = 0; i < boardColumns; i++)
				{
					MyShapeDrawable newDrawableLine = this.createRectShape(prevX, prevY, false, currentCol, currentRow, Edge.SOUTH);
					boardShapes[currentCol][currentRow][Edge.SOUTH] = newDrawableLine;
					prevX = prevX + BoardSettings.lineWidth;
					currentCol++;
				}
			}
			currentRow++;
			currentCol = 0;

		}
		
		this.drawGameBorder();
		
	}
	
	private void createAndAddNewLayoutBoardCircle(int prevX, int prevY) {
		ShapeDrawable circle = new ShapeDrawable(new OvalShape());
		circle.setBounds(prevX + BoardSettings.circleStartBounds, 
				prevY + BoardSettings.circleStartBounds, 
				prevX + BoardSettings.circleEndBounds, 
				prevY + BoardSettings.circleEndBounds );
		circle.getPaint().setColor(Color.WHITE);
		fillerShapes.add(circle);
		debugCirclesDrawn++;
	}
	
	private void drawGameBorder() {

		ShapeDrawable borderTop = new ShapeDrawable(new RectShape());
		borderTop.setBounds(0, 0, (int)BoardSettings.myCanvasWidth, BoardSettings.gameBorderWidth);

		ShapeDrawable borderBottom = new ShapeDrawable(new RectShape());
		borderBottom.setBounds(0, (int)BoardSettings.myCanvasHeight - BoardSettings.gameBorderWidth, (int)BoardSettings.myCanvasWidth, (int)BoardSettings.myCanvasHeight);

		ShapeDrawable borderLeft = new ShapeDrawable(new RectShape());
		borderLeft.setBounds(0, 0, BoardSettings.gameBorderWidth, (int)BoardSettings.myCanvasHeight - BoardSettings.gameBorderWidth);

		ShapeDrawable borderRight = new ShapeDrawable(new RectShape());
		borderRight.setBounds((int)BoardSettings.myCanvasWidth - BoardSettings.gameBorderWidth, 0, (int)BoardSettings.myCanvasWidth , (int)BoardSettings.myCanvasHeight);

		borderTop.getPaint().setColor(Color.WHITE);
		borderBottom.getPaint().setColor(Color.WHITE);
		borderLeft.getPaint().setColor(Color.WHITE);
		borderRight.getPaint().setColor(Color.WHITE);


		fillerShapes.add(borderLeft);
		fillerShapes.add(borderTop);
		fillerShapes.add(borderRight);
		fillerShapes.add(borderBottom);
		

	}
	
	private MyShapeDrawable createRectShape(int x, int y, boolean vertical, int col, int row, int edge)
	{
		Log.d("nevex", "creating shape with the following dimensions: "+x+", "+y+", "+vertical+", "+col+", "+row+", "+edge);
		MyShapeDrawable drawableLine;
		int width = BoardSettings.lineWidth;
		int height = BoardSettings.lineHeight;

		drawableLine = new MyShapeDrawable(new RectShape());
		drawableLine.getPaint().setColor(Color.TRANSPARENT);
		if ( vertical )
		{
			//	    	 drawableLine.edge = Edge.WEST;
			drawableLine.setEdge(row, col, edge, board);
			drawableLine.setBounds(x, y+BoardSettings.lineGap, x + height, y + width);
		}
		else
		{
			//	    	 drawableLine.edge = Edge.NORTH;
			drawableLine.setEdge(row, col, edge, board);
			drawableLine.setBounds(x+BoardSettings.lineGap, y, x + width, y + height);
			
			if ( col == 0 )
			{
				// in first column, so draw the first circle also
				this.createAndAddNewLayoutBoardCircle(BoardSettings.boardStartX, y);
			}
			// START HERE - COMMENT OUT THIS AND SEE WHAT HAPPENS - COUNT THE EDGES AND CIRCLES BEING ADDED
			this.createAndAddNewLayoutBoardCircle(x + width, y);
			
		}

		Log.d("nevex", "adding new shape for : row "+drawableLine.myEdge.getRow()+", col "+drawableLine.myEdge.getCol()+" , edge "+drawableLine.myEdge.getEdge());
		currentShapes.add(drawableLine);
		
		debugLinesDrawn++;
		return drawableLine;
	}

	
}
