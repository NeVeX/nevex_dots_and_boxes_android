package com.mark.level;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.graphics.drawable.shapes.RectShape;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;

import com.mark.GameActivity;
import com.mark.nevex.AIEngine;
import com.mark.nevex.Board;
import com.mark.nevex.Edge;
import com.mark.nevex.NeVeX;
import com.mark.nevex.Viper;

public class GameManager {

	private boolean nevexComputing;
	private MyShapeDrawable prevSelecetedShape;
	public ShapeFactory myShapeFactory;

	private Board b;
	public AIEngine aiEngine;
	private DrawLevel dl;
	
	private void resetBoard() {
		Scores.HumanScore = Scores.AIScore = 0;
	}
	
	
	public GameManager(DrawLevel dl)
	{
		this.resetBoard();
		this.dl = dl;
		b = new Board(this, BoardSettings.boardColumns, BoardSettings.boardRows);
		myShapeFactory = new ShapeFactory(b);
		myShapeFactory.DrawBoard();

		if ( GameActivity.aiEngine.equals("NeVeX"))
		{

			this.aiEngine = new NeVeX(b);
		}
		else
		{
			this.aiEngine = new Viper(b);
		}
	}
	
	public boolean makePlayerMoveInUI(MotionEvent event) {

		int x = (int) event.getX();
		int y = (int) event.getY();

		Log.d("Touching", "Event Co-ords: "+x+", "+y);


		if ( !this.nevexComputing && b.getEdgesLeft() > 0 )
			for (MyShapeDrawable d : myShapeFactory.currentShapes)
			{

				if ( d.getBounds().contains(x, y) && !d.alreadySelected)
				{
					Log.d("Touching", "Found shape for Event Co-ords: "+x+", "+y);
					//				Log.d("Shape Clicked", "drawable line touched with cor-ords: ["+x+", "+y+"]");
					Log.d("nevex", "Shape with edge selected: "+d.myEdge.getCol()+", "+d.myEdge.getRow()+" ,"+d.myEdge.getEdge());
					if (d.getPaint().getColor() == Color.TRANSPARENT)
					{
						d.getPaint().setColor(Color.RED);
						d.alreadySelected = true;
						setPrevShapeToNormalColor(null);
						dl.invalidate();
					}

					if (b.acceptMove(d, d.myEdge, 0) )
					{
						// player move valid, calling on the AI engine now
						dl.updateStatusGameText(aiEngine.getAIName()+" Is Computing....");
						this.nevexComputing = true;
						Log.d("nevex", "player move over");
						Log.d("nevex", "nevex is thinking.....");
						Edge e = aiEngine.pickEdge();
						d = findEdgeSelectedInShapes(e);
						Log.d("nevex", "nevex has made it's move: "+e.getCol()+", "+e.getRow()+" ,"+e.getEdge());

						while ( !b.acceptMove(d, e, 1) && b.getEdgesLeft() > 0)
						{
							Log.d("nevex", "nevex is thinking again.....");
							Log.d("nevex", "board accepted ths move by nevex. Finding shape to select on this move.");
							dl.invalidate();
							e = aiEngine.pickEdge();
							d = findEdgeSelectedInShapes(e);
							Log.d("nevex", "nevex has made it's move: "+e.getRow()+", "+e.getCol()+" ,"+e.getEdge());

						}
						Log.d("nevex", "board accepted ths move by nevex. Finding last shape to select on this move.");
						findEdgeSelectedInShapes(e);
						dl.invalidate();
						Log.d("nevex", "nevex move over");
						this.nevexComputing = false;
						dl.updateStatusGameText(aiEngine.getAIName()+" Made Move. Human, Make Your Move.");
					}
					else
					{
						// human player got a box
						//					placeTokenInsideWinnerBox(d);
						dl.updateStatusGameText("Human, Again, Make Your Move.");
						Log.d("nevex", "player gets to go again");
					}
					break;
				}
				else
				{
					//				Log.d("No Shape Clicked", "cor-ords: ["+x+", "+y+"]");
				}
			}

		if ( b.getEdgesLeft() < 1 )
		{
			this.gameOver();

		}
		dl.invalidate();
		return false;
	}
	
	private void gameOver() {
		if ( Scores.HumanScore > Scores.AIScore) 
		{
			dl.updateStatusGameText("Human Won The Game");
			Log.d("nevex", "Human Won The Game!");
		}
		else if ( Scores.HumanScore < Scores.AIScore) 
		{
			dl.updateStatusGameText(aiEngine.getAIName()+" Won The Game");
			Log.d("nevex", aiEngine.getAIName()+" Won The Game!");
		}
		else if ( Scores.HumanScore == Scores.AIScore) 
		{
			dl.updateStatusGameText("The Game Was A Tie");
			Log.d("nevex", "The Game Was A Tie!");
		}	
	}
	
	private MyShapeDrawable findEdgeSelectedInShapes(Edge e) {
		MyShapeDrawable selectedDrawableEdge = myShapeFactory.boardShapes[e.getCol()][e.getRow()][e.getEdge()];
		setPrevShapeToNormalColor(selectedDrawableEdge);
		selectedDrawableEdge.getPaint().setColor(Color.YELLOW);
		selectedDrawableEdge.alreadySelected = true;
		return selectedDrawableEdge;
	}
	
	private void setPrevShapeToNormalColor(MyShapeDrawable pShape) {
		if ( prevSelecetedShape != null )
		{
			prevSelecetedShape.getPaint().setColor(Color.BLUE);
		}
		prevSelecetedShape = pShape;
	}

	public void placeTokenInsideWinnerBox(int col, int row, int player)
	{
		ShapeDrawable circle = new ShapeDrawable(new OvalShape());
		BoxToken circleToken = this.myShapeFactory.boxBoundaries[col][row];
		circleToken.player = player;
		circle.setBounds(circleToken.tokenRect);
		if ( player == 0 ) 
		{
			circle.getPaint().setColor(Color.RED);
		}
		else {
			circle.getPaint().setColor(Color.BLUE);
		}
		myShapeFactory.fillerShapes.add(circle);
	}
	
	

	
}
