package com.mark.level;

public class BoardSettings {

	public static int lineWidth = 100;
	public static int lineHeight = 20;
	public static int boardStartX = 40;
	public static int boardStartY = 40;
	public static int gameBorderWidth = 20;
	public static int lineGap = 20;
	public static int circleStartBounds = 2;
	public static int circleEndBounds = 18;
	public static int boardPadding = 50;
	public static int boardRows, boardColumns;
	public static int myCanvasWidth, myCanvasHeight;
	
	public static void calculateDimensions() {
		myCanvasWidth = (BoardSettings.boardColumns * BoardSettings.lineWidth) 
				+ ( (BoardSettings.boardColumns) * BoardSettings.lineGap)
				+ (BoardSettings.gameBorderWidth * 2) 
				/* + ( boardPadding * 2) */;
		myCanvasHeight = (BoardSettings.boardRows * BoardSettings.lineWidth) 
				+ ( (BoardSettings.boardRows) * BoardSettings.lineGap) 
				+ (BoardSettings.gameBorderWidth * 2) 
				/*  + ( boardPadding * 2) */;




		
	}
	
//	public BoardSettings()
//	{
//		boardStartX = gameBorderWidth + lineGap;
//		boardStartY = boardStartX;
//		circleStartBounds = (int) ((int) lineGap * 0.3);
//		circleEndBounds = (int) ((int) lineGap * 0.7);
//	}
	
}
