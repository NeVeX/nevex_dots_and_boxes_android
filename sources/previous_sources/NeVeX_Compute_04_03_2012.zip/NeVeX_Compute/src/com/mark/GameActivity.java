package com.mark;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.TextView;

import com.mark.level.DrawLevel;
import com.mark.level.Scores;
import com.mark.nevex.NeVeX;
import com.mark.nevex.Viper;

public class GameActivity extends Activity {
	
	public static int Rows = 4;
	public static int Columns = 3;
	public static String aiEngine;
	
	DrawLevel drawLevel;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        drawLevel = new DrawLevel(this);
        
        
        
        Bundle b = getIntent().getExtras();
        String ai = b.getString("AI");
        if ( b != null ) 
        {
        	if ( ai.equals("NeVeX"))
			{
				aiEngine = "NeVeX";
				
			}
        	if ( ai.equals("Viper"))
			{
				
        		aiEngine = "Viper";
			}
        	setContentView(R.layout.main_game);
        	
        }
        
        
        
        
       
        
//        setContentView(drawLevel);
    }
    


    
//    public void ShapeClicked(View v)
//    {
//    	Log.d("TEST", "DrawLevel Class CLicked");
//    }

//    protected void onCreate(Bundle savedInstanceState) {
//    super.onCreate(savedInstanceState);
//    mCustomDrawableView = new CustomDrawableView(this);
//
//    setContentView(mCustomDrawableView);
//    }
}